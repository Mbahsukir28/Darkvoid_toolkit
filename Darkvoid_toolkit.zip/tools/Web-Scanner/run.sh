#!/bin/bash
# Web Scanner by Void Walker IDN

read -p "Enter URL (e.g., https://example.com): " target

echo "[*] Scanning headers..."
curl -I "$target"

echo -e "\n[*] Checking open ports (common)..."
for port in 80 443 21 22 8080 3306; do
    (echo > /dev/tcp/$(echo $target | sed 's~http[s]*://~~')/$port) >/dev/null 2>&1 && \
    echo "Port $port is open"
done

echo -e "\n[+] Done."
