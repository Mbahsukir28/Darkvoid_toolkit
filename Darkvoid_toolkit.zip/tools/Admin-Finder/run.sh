#!/bin/bash
# Admin Finder by Void Walker IDN

read -p "Enter target website (e.g., https://example.com): " site
wordlist=(admin admin/login administrator login adminpanel panel admincp)

echo "[*] Scanning for admin pages..."
for word in "${wordlist[@]}"; do
    url="$site/$word"
    if curl -s -o /dev/null -w "%{http_code}" $url | grep -q "200"; then
        echo "[+] Found: $url"
    fi
done
