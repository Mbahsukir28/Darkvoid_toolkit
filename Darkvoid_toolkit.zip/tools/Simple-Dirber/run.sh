#!/bin/bash
# Simple Dir Bruter by Void Walker IDN

read -p "Enter target URL (e.g., https://example.com): " url
read -p "Enter path to wordlist: " wordlist

while read dir; do
    full_url="$url/$dir"
    status=$(curl -s -o /dev/null -w "%{http_code}" "$full_url")
    if [ "$status" == "200" ]; then
        echo "[+] Found: $full_url"
    fi
done < $wordlist
