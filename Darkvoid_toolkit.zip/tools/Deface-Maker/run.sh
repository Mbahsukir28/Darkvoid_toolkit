#!/bin/bash
# Deface Maker by Void Walker IDN

read -p "Enter title for deface page: " title
read -p "Enter message (e.g., Hacked by Void Walker): " message
read -p "Enter filename (e.g., index.html): " filename

cat <<EOF > $filename
<!DOCTYPE html>
<html>
<head><title>$title</title></head>
<body style="background:black;color:red;text-align:center;">
  <h1>$message</h1>
  <p>Contact: voidwalker@protonmail.com</p>
</body>
</html>
EOF

echo "[+] Deface page created: $filename"
