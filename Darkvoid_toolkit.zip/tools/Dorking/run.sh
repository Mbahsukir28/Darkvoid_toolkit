#!/bin/bash
# Dorking Tool by Void Walker IDN

read -p "Enter dork (e.g., inurl:admin/login.php): " dork

echo "[*] Searching with Google..."
curl -s -A "Mozilla/5.0" "https://www.google.com/search?q=$dork" | grep -Eo 'http[s]?://[^&]+' | sed 's/url?q=//g' | uniq | tee dork_results.txt

echo "[+] Results saved to dork_results.txt"
