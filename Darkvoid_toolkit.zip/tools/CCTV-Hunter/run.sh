#!/bin/bash
# CCTV Hunter by Void Walker IDN

echo "[*] Searching open CCTV cameras..."
echo "Using inurl:view/view.shtml"
curl -s -A "Mozilla/5.0" "https://www.google.com/search?q=inurl:view/view.shtml" | grep -Eo 'http[s]?://[^&]+' | uniq | tee cctv_results.txt
echo "[+] Results saved to cctv_results.txt"
