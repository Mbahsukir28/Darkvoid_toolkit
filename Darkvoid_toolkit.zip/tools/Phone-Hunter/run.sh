#!/bin/bash
# Phone Hunter by Void Walker IDN

read -p "Enter phone number (with country code, e.g., +628123456789): " phone
echo "[*] Searching info for: $phone"

curl -s "https://htmlweb.ru/geo/api.php?json&telcod=$phone" | jq
